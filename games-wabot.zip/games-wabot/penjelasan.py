jika kalian keluar dari termux trus scriptnya harus install ulang
tinggal ketik aja

1 cd (nama file)
jika file nya terdeteksi tinggal klian start aja dengan cara
2 npm start
atsu
3 node .