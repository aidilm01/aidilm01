export declare class MissingAdapterError extends Error {
    constructor();
}
